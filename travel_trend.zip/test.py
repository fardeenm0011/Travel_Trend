import requests
import json

API_KEY = 'S1kqKzUz1YCLY2mGIuKPWUXrJSaDUEu1'  # Replace with your NYTimes API key

def get_travel_news():
    url = f'https://api.nytimes.com/svc/topstories/v2/travel.json?api-key={API_KEY}'
    out = {}
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raise an exception if the request was unsuccessful
        data = response.json()
        
        articles = data['results']
        cnt = 0
        for article in articles:
            if article['section'] == "travel":
                title = article['title']
                abstract = article['abstract']
                url = article['url']
                byline = article['byline']
                imglinks = article['multimedia']
                if len(imglinks)>0: 
                    imglink = imglinks[0]['url']
                else:
                    imglink = "none"
                created_date = article['created_date'].split('T')[0]
                print(f'Title: {title}')
                print(f'Abstract: {abstract}')
                print(f'URL: {url}')
                print('---')


                cnt += 1
                out[str(cnt)] = {'title':title, 'abstract':abstract, 'url':url, 'byline':byline, 'created_date':created_date, 'imglink':imglink}


        with open("result.json", 'w', encoding='utf-8') as json_file:
            json.dump(out, json_file, indent='\t', ensure_ascii=False)
    except requests.exceptions.RequestException as e:
        print(f'Error: {e}')


get_travel_news()