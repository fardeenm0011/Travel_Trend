import { fireEvent } from '@testing-library/react';
import { Header } from '@/components/Landing/Header';
import { render } from '@/test-utils';

describe('Header Component', () => {
    const links = [
      { link: '/home', label: 'Home' },
      { link: '/about', label: 'About'},
      { link: '/contact', label: 'Contact' }
    ];
  
    it('renders the Header component correctly', () => {
      const { getByText } = render(<Header links={links} />);
  
      expect(getByText('Home')).toBeInTheDocument();
      expect(getByText('About')).toBeInTheDocument();
      expect(getByText('Contact')).toBeInTheDocument();
    });
  
    it('opens the menu when clicking on the Burger component', () => {
      const { getByRole } = render(<Header links={links} />);
  
      fireEvent.click(getByRole('button'));
    });
  
    it('does not navigate when clicking on the links', () => {
      const { getByText } = render(<Header links={links} />);
  
      fireEvent.click(getByText('Home'));
      fireEvent.click(getByText('About'));
      fireEvent.click(getByText('Contact'));
  
    });
});