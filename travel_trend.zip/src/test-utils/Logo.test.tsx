import { Logo } from '@/components/Logo/Logo';
import { render } from '@/test-utils';

describe('Logo component Test', () => {
    it('renders logo image correctly', () => {
      const { getByAltText } = render(<Logo />);
      const logoImage = getByAltText('img');
      
      expect(logoImage).toBeInTheDocument();
      expect(logoImage).toHaveAttribute('src', '/static/images/logo.png');
    });
  
    it('redirects to home page on click', () => {
      const { getByAltText } = render(<Logo />);
      const logoImage = getByAltText('img');
  
      expect(logoImage.parentElement).toHaveAttribute('href', '/');
    });
});