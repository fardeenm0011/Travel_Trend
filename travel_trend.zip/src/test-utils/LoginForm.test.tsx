import { fireEvent } from '@testing-library/react';
import { useRouter } from 'next/navigation';
import { LoginForm } from '@/components/Auth/LoginForm';
import { render } from '@/test-utils';

jest.mock('next/navigation', () => ({
    useRouter: jest.fn(),
}));

describe('LoginForm Component Test', () => {
  it('renders email and password input fields', () => {
    const { getByPlaceholderText } = render(<LoginForm />);
    expect(getByPlaceholderText('test@example.com')).toBeInTheDocument();
    expect(getByPlaceholderText('Your password')).toBeInTheDocument();
  });

  it('renders remember me checkbox and forgot password link', () => {
    const { getByLabelText, getByText } = render(<LoginForm />);
    expect(getByLabelText('Remember me')).toBeInTheDocument();
    expect(getByText('Forgot Password？')).toBeInTheDocument();
  });

  it('calls router.push when Sign In button is clicked', () => {
    const mockPush = jest.fn();
    (useRouter as jest.Mock).mockReturnValue({ push: mockPush });

    const { getByText } = render(<LoginForm />);
    fireEvent.click(getByText('Sign In'));

    expect(mockPush).toHaveBeenCalledWith('/dashboard');
  });
});
