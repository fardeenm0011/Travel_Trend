import { fireEvent } from '@testing-library/react';
import { useRouter } from 'next/navigation';
import { HeroSection } from '@/components/Landing/HeroSection'; 
import { render } from '@/test-utils';

jest.mock('next/navigation', () => ({
    useRouter: jest.fn(),
}));

describe('HeroSection Component Test', () => {
    it('renders the component', () => {
        const { getByText } = render(<HeroSection />);
        // You can use `screen` to query for elements and assert expectations
        expect(getByText('Travel Trends & Aviation News')).toBeInTheDocument();
    });
  
    it('calls router.push when the button is clicked', () => {
        const mockPush = jest.fn();
        (useRouter as jest.Mock).mockReturnValue({ push: mockPush });

        const { getByText } = render(<HeroSection />);
        fireEvent.click(getByText('View List of Travel News'));

        expect(mockPush).toHaveBeenCalledWith('/dashboard');
    });
});