import { NewsList } from '@/components/Dashboard/NewsList';
import { render } from '@/test-utils';

describe('NewsList component', () => {
    const newsItem = {
        item: {
            title: 'Test Title',
            abstract: 'Test Abstract',
            url: 'https://www.example.com',
            byline: 'Test Byline',
            created_date: '2022-01-01',
            imglink: 'https://www.example.com/image.jpg',
        },
    };
  
    it('renders news item with correct data', () => {
        const { getByText, getByAltText } = render(<NewsList item={newsItem.item} />);

        expect(getByText(newsItem.item.title)).toBeInTheDocument();
        expect(getByText(newsItem.item.abstract)).toBeInTheDocument();
        expect(getByText(newsItem.item.byline)).toBeInTheDocument();
        expect(getByText(newsItem.item.created_date)).toBeInTheDocument();
        expect(getByAltText('listImg')).toHaveAttribute('src', newsItem.item.imglink);
    });
});