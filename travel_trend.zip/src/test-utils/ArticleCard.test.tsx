import { ArticleCard } from '@/components/Landing/ArticleCard';
import { render } from '@/test-utils';

describe('ArticleCard Component', () => {
    
    it('renders the features section properly', () => {
        const title = 'Featured News';
        const description = 'Check out our top news features!';
        
        const { getByText } = render(<ArticleCard title={title} description={description} />);
        
        const titleElement = getByText(title);
        expect(titleElement).toBeInTheDocument();
        
        const descriptionElement = getByText(description);
        expect(descriptionElement).toBeInTheDocument();
    });

    it('renders four images in the grid', () => {
        const { getAllByAltText } = render(<ArticleCard title="Test Title" description="Test Description" />);
        
        const images = getAllByAltText('img');
        expect(images).toHaveLength(4);
    });
});