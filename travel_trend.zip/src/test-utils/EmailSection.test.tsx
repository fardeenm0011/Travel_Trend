import { fireEvent } from '@testing-library/react';
import { EmailSection } from '@/components/Landing/EmailSection'; 
import { render } from '@/test-utils';

describe('EmailSection Component', () => {
    it('renders email input and subscribe button', () => {
        const { getByPlaceholderText, getByText } = render(<EmailSection />);
        const emailInput = getByPlaceholderText('Your email');
        expect(emailInput).toBeInTheDocument();

        const subscribeButton = getByText('Subscribe');
        expect(subscribeButton).toBeInTheDocument();
    });
  
    it('subscribes to newsletter on button click', () => {
        const { getByPlaceholderText, getByText } = render(<EmailSection />);
        const emailInput = getByPlaceholderText('Your email');
        const subscribeButton = getByText('Subscribe');

        fireEvent.change(emailInput, { target: { value: 'test@example.com' } });
        expect(emailInput).toHaveValue('test@example.com');

        // Mock the subscription function and test if it's called on button click
        const mockSubscribe = jest.fn();
        subscribeButton.onclick = mockSubscribe;
        fireEvent.click(subscribeButton);
        expect(mockSubscribe).toHaveBeenCalled();
    });
});