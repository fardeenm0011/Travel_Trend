import { fireEvent } from '@testing-library/react';
import { render } from '@/test-utils';
import { ThemeSwitcher } from '../components/ThemeSwitcher/ThemeSwitcher';

describe('ThemeSwitcher', () => {
  it('renders theme switcher and changes theme on radio button click', () => {
    const { getByText, getByLabelText } = render(<ThemeSwitcher />);

    // Verify the initial theme mode label
    expect(getByText('Theme Mode')).toBeInTheDocument();

    // Simulate clicking on the "Dark" radio button
    fireEvent.click(getByLabelText('Dark'));
    fireEvent.click(getByLabelText('Light'));

    // Verify that the theme changed to "dark"
    // expect(document.body).toHaveClass('mantine-color-scheme-dark');
  });
});
