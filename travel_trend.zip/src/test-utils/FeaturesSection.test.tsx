import { FeaturesSection } from '@/components/Landing/FeaturesSection';
import { render } from '@/test-utils';

describe('FeaturesSection Component', () => {
    const featuresData = [
        {
            title: 'Top News 1',
            description: 'Suspendisse ultrices nibh non cursus sagittis. Morbi dictum consequat ex, quis finibus magna.',
        },
        {
            title: 'Top News 2',
            description: 'Suspendisse ultrices nibh non cursus sagittis. Morbi dictum consequat ex, quis finibus magna.',
        },
        {
            title: 'Top News 3',
            description: 'Suspendisse ultrices nibh non cursus sagittis. Morbi dictum consequat ex, quis finibus magna.',
        },
        {
            title: 'Top News 4',
            description: 'Suspendisse ultrices nibh non cursus sagittis. Morbi dictum consequat ex, quis finibus magna.',
        },
    ];

    it('renders the features section properly', () => {
        const title = 'Featured News';
        const description = 'Check out our top news features!';
        
        const { getByText } = render(<FeaturesSection title={title} description={description} />);
        
        const titleElement = getByText(title);
        expect(titleElement).toBeInTheDocument();
        
        const descriptionElement = getByText(description);
        expect(descriptionElement).toBeInTheDocument();

        featuresData.forEach((feature) => {
            const featureTitle = getByText(feature.title);
            expect(featureTitle).toBeInTheDocument();
            // const featureDescription = getByText(feature.description);
            // expect(featureDescription).toBeInTheDocument();
        });
    });
});