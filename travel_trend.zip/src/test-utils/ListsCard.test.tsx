import { fireEvent } from '@testing-library/react';
import React from 'react';
import { ListsCard } from '@/components/Dashboard/ListsCard';
import { render } from '@/test-utils';

describe('ListsCard Component', () => {
    it('renders correctly', () => {
        const { getByText } = render(<ListsCard />);
        expect(getByText('Aviation News')).toBeInTheDocument();
    });

    // it('displays news items', () => {
    //     const { getByText } = render(<ListsCard />);

    //     // Replace these with actual test data from your application
    //     const newsItemTitle = 'Sample News Title';
    //     const newsItemUrl = 'http://sampleurl.com';

    //     // Mock the news data to be used in the component
    //     const newsData = [{ title: newsItemTitle, url: newsItemUrl }];
    //     jest.spyOn(React, 'useState').mockImplementation(() => [newsData, jest.fn()]);

    //     // Check if the news item is displayed correctly
    //     expect(getByText(newsItemTitle)).toBeInTheDocument();
    // });

    // it('handles button click event', () => {
    //     const { getByRole } = render(<ListsCard />);

    //     // Mock the window.open function
    //     const originalOpen = window.open;
    //     window.open = jest.fn();

    //     // Trigger a button click event
    //     const button = getByRole('button');
    //     fireEvent.click(button);

    //     // Verify that the window.open function was called with the correct arguments
    //     expect(window.open).toHaveBeenCalledWith('http://yournewsurl.com', '_blank');

    //     // Restore the original window.open function
    //     window.open = originalOpen;
    // });
});