import { Footer } from '@/components/Footer/Footer';
import { render } from '@/test-utils';

describe('Footer component Test', () => {
  test('renders logo and links', () => {
    const { getByText, getByRole } = render(<Footer />);

    // Check if the links are rendered
    const aboutLinks = getByText(/about/i);
    expect(aboutLinks).toBeInTheDocument();

    const projectLinks = getByText(/project/i);
    expect(projectLinks).toBeInTheDocument();

    const communityLinks = getByText(/community/i);
    expect(communityLinks).toBeInTheDocument();

    // Check if the logo is rendered
    const logo = getByRole('img');
    expect(logo).toBeInTheDocument();
  });
});