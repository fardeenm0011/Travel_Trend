import { PageContainer } from '@/components/PageContainer/PageContainer';
import { render } from '@/test-utils';
// import userEvent from '@testing-library/user-event';
// import { MemoryRouter } from 'react-router-dom';

describe('PageContainer Component', () => {
    it('renders title correctly', () => {
        const { getByText } = render(
            <PageContainer title="Test Title">
                <div>Test Content</div>
            </PageContainer>
        );
        const titleElement = getByText('Test Title');
        expect(titleElement).toBeInTheDocument();
    });
  
    // it('renders breadcrumbs if items prop is provided', () => {
    //     render(
    //     <MemoryRouter>
    //         <PageContainer
    //         title="Test Title"
    //         items={[
    //             { label: 'Home', href: '/home' },
    //             { label: 'Section', href: '/section' },
    //             { label: 'Subsection', href: '/subsection' }
    //         ]}
    //         >
    //         <div>Test Content</div>
    //         </PageContainer>
    //     </MemoryRouter>
    //     );

    //     const breadcrumbHome = screen.getByText('Home');
    //     const breadcrumbSection = screen.getByText('Section');
    //     const breadcrumbSubsection = screen.getByText('Subsection');
    //     expect(breadcrumbHome).toHaveAttribute('href', '/home');
    //     expect(breadcrumbSection).toHaveAttribute('href', '/section');
    //     expect(breadcrumbSubsection).toHaveAttribute('href', '/subsection');
    // });
  
    // it('does not render breadcrumbs if items prop is not provided', () => {
    //     render(
    //     <PageContainer title="Test Title">
    //         <div>Test Content</div>
    //     </PageContainer>
    //     );

    //     const breadcrumb = screen.queryByRole('link');
    //     expect(breadcrumb).not.toBeInTheDocument();
    // });
});
  