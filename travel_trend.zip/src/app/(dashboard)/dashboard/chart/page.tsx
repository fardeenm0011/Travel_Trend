import { PageContainer } from '@/components/PageContainer/PageContainer';

export default function Chart() {
	return <PageContainer title="Chart">Chart</PageContainer>;
}
