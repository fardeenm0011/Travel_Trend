import { PageContainer } from '@/components/PageContainer/PageContainer';

export default function Settings() {
	return <PageContainer title="Settings">Settings</PageContainer>;
}
