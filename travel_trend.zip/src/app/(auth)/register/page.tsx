import { RegisterForm } from '@/components/Auth/RegisterForm';

export default function Register() {
	return (
		<RegisterForm />
	);
}
