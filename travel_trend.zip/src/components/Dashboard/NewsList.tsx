import { Avatar, Group, Text } from '@mantine/core';
import { IconCalendarTime, IconPlane } from '@tabler/icons-react';
import classes from './NewsList.module.css';

interface NewsItem {

  title: string;
  abstract: string;
  url: string;
  byline: string;
  created_date: string;
  imglink: string;
}

interface NewsListProps {
  item: NewsItem;
}

export const NewsList: React.FC<NewsListProps> = ({ item }) => {
  return (
    <div>
      <Group wrap="nowrap">
        <Avatar
          src={item.imglink}
          size={94}
          radius="md"
          alt='listImg'
        />
        <div>
          <Text fz="xs" tt="uppercase" fw={700} c="dimmed">
            {item.title}
          </Text>

          <Text fz="lg" fw={500} className={classes.name}>
            {item.abstract}
          </Text>

          <Group wrap="nowrap" gap={10} mt={3}>
            <IconPlane stroke={1.5} size="1rem" className={classes.icon} />
            <Text fz="xs" c="dimmed">
              {item.byline}
            </Text>
          </Group>

          <Group wrap="nowrap" gap={10} mt={5}>
            <IconCalendarTime stroke={1.5} size="1rem" className={classes.icon} />
            <Text fz="xs" c="dimmed">
              {item.created_date}
            </Text>
          </Group>
        </div>
      </Group>
    </div>
  );
};