import { Card, Group, Text, UnstyledButton } from '@mantine/core';
import { useEffect, useState } from 'react';
import classes from './ListsCard.module.css';
import { NewsList } from './NewsList';

export function ListsCard() {

	const [newsData, setNewsData] = useState<any[]>([]);
	const apiKey = process.env.API_KEY;
	console.log("asdfasdf", apiKey);
	useEffect(() => {
		const fetchNewsData = async () => {
		try {
			const response = await fetch('/news.json');
			if (!response.ok) {
			throw new Error('Failed to fetch news data');
			}
			const data = await response.json();
			const newsItems = Object.values(data);
			setNewsData(newsItems);
		} catch (error) {
			console.error(error);
		}
		};

		fetchNewsData();
	}, []);
	const handleButtonClick = (event: React.MouseEvent<HTMLButtonElement>, item: Object) => {
		// Handle button click with item props
		console.log('Button clicked!', item);
		window.open(item.url, '_blank');
	};

	const items = newsData.map((item: any, index: number) => (
		<Group justify="space-between" className={classes.item} wrap="nowrap" gap="xl" key={item.title}>
			<UnstyledButton onClick={(event) => handleButtonClick(event, item)}><NewsList key={index} item={item}/></UnstyledButton>
			{/* <Switch onLabel="ON" offLabel="OFF" className={classes.switch} size="lg" /> */}
		</Group>
	));

	return (
		<Card withBorder radius="md" p="xl" className={classes.card}>
			<Text fz="lg" className={classes.title} fw={500}>
				Aviation News
			</Text>
			<Text fz="xs" c="dimmed" mt={3} mb="xl">
				Choose what travel you want to see
			</Text>
			{items}
		</Card>
	);
}