'use client';

import { Badge, Button, Card, Container, Group, Image, SimpleGrid, Space, Text, Title } from '@mantine/core';
import { useEffect, useState } from 'react';
import classes from './FeatureSection.module.css';

// export function SetTopNews() {

// 	const [newsData, setNewsData] = useState<any[]>([]);

// 	useEffect(() => {
// 		const fetchNewsData = async () => {
// 		try {
// 			const response = await fetch('/news.json');
// 			if (!response.ok) {
// 			throw new Error('Failed to fetch news data');
// 			}
// 			const data = await response.json();
// 			const newsItems = Object.values(data);
// 			setNewsData(newsItems);
// 		} catch (error) {
// 			console.error(error);
// 		}
// 		};

// 		fetchNewsData();
// 	}, []);
// 	if (!newsData) {
// 		return null; // Return null while data is being fetched to avoid rendering with empty data
// 	}
// 	let topNewsData = [newsData[0],newsData[1],newsData[2],newsData[3]];
// 	return topNewsData;
// }

interface FeatureProps {
	title: React.ReactNode;
	abstract: React.ReactNode;
	url: React.ReactNode;
	byline: React.ReactNode;
	created_date: React.ReactNode;
	imglink: React.ReactNode;
}

export function Feature({ title, abstract, url, created_date, imglink }: FeatureProps) {
	return (

		<Card withBorder radius="md" p="md" className={classes.card}>
			<Card.Section>
				<Image src={imglink} alt="Top News" height={180} />
			</Card.Section>

			<Card.Section className={classes.section} mt="md">
				<Group justify="apart">
					<Text fz="md" mx={10} className={classes.news_title}>
						{title}<Badge size="lg" variant="light">
						{created_date}</Badge>
					</Text>
					<Button radius="md" style={{ flex: 1 }} mx='lg'>
						<a href={url} className={classes.link} target='_black'>Read Article</a>
					</Button>
				</Group>
			</Card.Section>
			<Group mt="xs">
			<Text fz="sm" mt="xs" className={classes.description}>
				{abstract}
				</Text>
			</Group>
		</Card>
	);
}

// interface FeaturesGridProps {
// 	data?: FeatureProps[];
// }

export function FeaturesSection() {
	const [newsData, setNewsData] = useState<any[]>([]);

	useEffect(() => {
		const fetchNewsData = async () => {
		try {
			const response = await fetch('/news.json');
			if (!response.ok) {
			throw new Error('Failed to fetch news data');
			}
			const data = await response.json();
			const newsItems = Object.values(data);
			setNewsData(newsItems.slice(0, 4));
		} catch (error) {
			console.error(error);
		}
		};

		fetchNewsData();
	}, []);
	if (!newsData) {
		return null;
	}
	return (
		<Container className={classes.wrapper}>
			<Title className={classes.title}>Top News</Title>
			<Space h="md" />
			<SimpleGrid
				mt={60}
				cols={{ base: 1, sm: 2, lg: 4 }}
				spacing={{ base: 'lg', md: 'lg', lg: 'xl' }}
				className={classes.grid}
			>
				{newsData.map((item, index) => (
					<Feature {...item} key={index} />
				))}
			</SimpleGrid>
		</Container>
	);
}
