'use client';

import { Button, Container, Group, Image, Text, Title } from '@mantine/core';
import { IconArrowRight, IconStar } from '@tabler/icons-react';
import { useRouter } from 'next/navigation';
import classes from './HeroSection.module.css';

export function HeroSection() {
	const router = useRouter();

	return (
		<div className={classes.background}>
		<Container pt="sm" size="lg">
			<div className={classes.inner}>
				<Image src="/static/images/Airplane.png" className={classes.image} alt="img" />
				<Title className={classes.title}>Travel Trends & Aviation News</Title>
				<Title className={classes.subtitle}>
					Travel Around The World
				</Title>

				<Group mt={40}>
					<Button
						size="lg"
						className={classes.control}
						onClick={() => {
							router.push('/dashboard');
						}}
						rightSection={<IconArrowRight />}
					>
						View List of Travel News
					</Button>
					{/* <Button
						variant="outline"
						size="lg"
						className={classes.control}
						onClick={() => {
							// open github
							window.open('https://github.com/jotyy/mantine-admin');
						}}
						rightSection={<IconStar />}
					>
						Give a Star
					</Button> */}
				</Group>
			</div>
		</Container>
		</div>
	);
}
