'use client';

import { Button, Container, TextInput, Title } from '@mantine/core';
import classes from './EmailSection.module.css';

export function EmailSection() {
	return (
		<Container className={classes.wrapper}>
			<Title order={3} className={classes.title}>
			Subscribe Newsletter &  get letest news
			</Title>
			<div className={classes.controls}>
				<TextInput
					placeholder="Your email"
					classNames={{ input: classes.input, root: classes.inputWrapper }}
				/>
				<Button className={classes.control}>Subscribe</Button>
			</div>
		</Container>
	);
}
