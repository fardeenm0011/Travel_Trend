'use client';

import { Container, Image, SimpleGrid, Space, Text, Title } from '@mantine/core';

import classes from './ArticleCard.module.css';


interface ArticleCardProps {
	title: React.ReactNode;
	description: React.ReactNode;
}

export function ArticleCard({ title, description }: ArticleCardProps) {

	return (
		<Container className={classes.wrapper}>
			<Title className={classes.title}>{title}</Title>
			<Space h="md" />

			<Container size={560} p={0}>
				<Text size="sm" className={classes.description}>
					{description}
				</Text>
			</Container>

			<SimpleGrid
				mt={60}
				cols={{ base: 1, sm: 2, lg: 4 }}
				spacing={{ base: 'lg', md: 'lg', lg: 'xl' }}
				className={classes.grid}
			>
				<Image src="/static/images/travelar1.png" className={classes.image} alt="img"/>
				<Image src="/static/images/travelar2.png" className={classes.image} alt="img"/>
				<Image src="/static/images/travelar3.png" className={classes.image} alt="img"/>
				<Image src="/static/images/travelar4.png" className={classes.image} alt="img"/>
			</SimpleGrid>
		</Container>
	);
}
