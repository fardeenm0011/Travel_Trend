export const mockData = [
	{
		title: 'BTC',
		value: '$13,456',
		diff: 34,
	},
	{
		title: 'ETH',
		value: '$4,145',
		diff: -13,
	},
	{
		title: 'DOGE',
		value: '$ 0.745',
		diff: 18,
	},
];
