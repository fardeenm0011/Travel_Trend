module.exports = {
	reactStrictMode: true,
	swcMinify: true,
	experimental: {
		optimizePackageImports: ['@mantine/core', '@mantine/hooks'],
	},
};
